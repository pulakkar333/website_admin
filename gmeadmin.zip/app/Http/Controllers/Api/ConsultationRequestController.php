<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\ConsultationRequest;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class ConsultationRequestController extends Controller
{
    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'full_name' => 'required|string|max:255',
            'organization_name' => 'required|string|max:255',
            'email' => 'required|email|max:255',
            'phone' => 'required|string|max:255',
            'topic_of_inquiry' => 'required|in:Product Info,Technical,Service,Training,Other',
            'message' => 'nullable|string',
            'file' => 'nullable|file|mimes:pdf,jpg,jpeg,png,doc,docx|max:5120',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'errors' => $validator->errors()
            ], 422);
        }

        $data = $request->all();

        // Handle file upload
        if ($request->hasFile('file')) {
            $destinationPath = public_path('uploads/consultation-requests');
            
            // Make sure the directory exists
            if (!file_exists($destinationPath)) {
                mkdir($destinationPath, 0755, true);
            }

            $file = $request->file('file');
            $fileName = time() . '_' . $file->getClientOriginalName();
            $file->move($destinationPath, $fileName);
            $data['file'] = 'uploads/consultation-requests/' . $fileName;
        }

        $consultationRequest = ConsultationRequest::create($data);

        return response()->json([
            'success' => true,
            'message' => 'Your consultation request has been submitted successfully!',
            'data' => $consultationRequest
        ], 201);
    }
}
