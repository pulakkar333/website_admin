<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ConsultationRequest extends Model
{
    use HasFactory;

    protected $fillable = [
        'full_name',
        'organization_name',
        'email',
        'phone',
        'topic_of_inquiry',
        'message',
        'file',
    ];
}
